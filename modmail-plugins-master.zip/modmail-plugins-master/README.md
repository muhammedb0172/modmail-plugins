# Plugin Examples

Check out plugin wiki [here](https://github.com/kyb3r/modmail/wiki/Plugins)
